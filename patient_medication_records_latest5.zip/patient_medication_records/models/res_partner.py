import datetime
import math
from dateutil.relativedelta import relativedelta
from odoo.tools import float_is_zero, float_compare
from odoo import api, fields, models, SUPERUSER_ID, _  # imports fields module and models module
from odoo.exceptions import ValidationError
from odoo.tools.misc import formatLang, get_lang

class ResPartner(models.Model):
    _inherit = 'res.partner'

    def name_get(self):
        res = []
        for account in self:
            res.append((account.id, '%s' % (account.name)))
        return res

    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        if args is None:
            args = []
        domain = args + ['|', ('phone', operator, name), ('name', operator, name)]
        return self._search(domain, limit=limit, access_rights_uid=name_get_uid)

    @api.depends('partner_id')
    def action_open_pos(self):
        for record in self:
            return {
                'name': 'POS records for ' + record.name,
                'view_mode': 'list',
                'view_type': 'list',
                'res_model': 'pos.order',
                'type': 'ir.actions.act_window',
                'target': 'current',
                'domain': [('partner_id', '=', record.name)],
            }

    def _compute_pos_order_count(self):
        # retrieve all children partners and prefetch 'parent_id' on them
        all_partners = self.with_context(active_test=False).search([('id', 'child_of', self.ids)])
        all_partners.read(['parent_id'])

        pos_order_groups = self.env['pos.order'].read_group(
            domain=[('partner_id', 'in', all_partners.ids)],
            fields=['partner_id'], groupby=['partner_id']
        )
        partners = self.browse()
        for group in pos_order_groups:
            partner = self.browse(group['partner_id'][0])
            while partner:
                if partner in self:
                    partner.pos_order_count += group['partner_id_count']
                    partners |= partner
                partner = partner.parent_id
        (self - partners).pos_order_count = 0

    """#@api.depends('import_name.program', 'prog_name')
    def _compute_pos_count2(self):
        for record in self:
            record_count = self.env['pos.order'].sudo().search_count([('partner_id', '=', self.id)])
            record.record_count = record_count"""

    pos_order_count = fields.Integer(compute='_compute_pos_order_count', string='Sale Order Count')
    x_gender = fields.Selection([('male', 'M'), ('female', 'F')], string='Gender')
    x_dob = fields.Date(string="D.O.B", store=True)
    partner_labels_width = fields.Float(
        "Width",
        default=60,
        help="Width in millimeters",
        required=True,
    )
    partner_labels_height = fields.Float(
        "Height",
        default=42.3,
        help="Height in millimeters",
        required=True,
    )
    partner_labels_padding = fields.Float(
        "Padding",
        default=5,
        help="Padding in millimeters",
        required=True,
    )
    partner_labels_margin_top = fields.Float(
        string="Margin Top",
        default=1,
        help="Margin top in millimeters",
        required=True,
    )
    partner_labels_margin_bottom = fields.Float(
        string="Margin Bottom",
        default=1,
        help="Margin bottom in millimeters",
        required=True,
    )
    partner_labels_margin_left = fields.Float(
        string="Margin Left",
        default=1,
        help="Margin left in millimeters",
        required=True,
    )
    partner_labels_margin_right = fields.Float(
        string="Margin Right",
        default=1,
        help="Margin right in millimeters",
        required=True,
    )
    x_partner_discount = fields.Float(string="Partner discount")
