import datetime
import math
from dateutil.relativedelta import relativedelta
from odoo.tools import float_is_zero, float_compare
from odoo import api, fields, models, SUPERUSER_ID, _  # imports fields module and models module
from odoo.exceptions import ValidationError
from odoo.tools.misc import formatLang, get_lang
import werkzeug


class Refill_request(models.Model):
    _name = 'refill.request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Refill request'
    _rec_name = 'name_seq'
    _order = 'remaining_days ASC'

    @api.model
    def create(self, vals):
        """field1 = self.env['patient.prescription'].search([('name', '=', 10)])
        field1.form_state = "draft"
        for records in field1:
            print(records.name)
        vals.update({'day': field1})"""
        if vals.get('name_seq', 'New') == 'New':
            vals['name_seq'] = self.env['ir.sequence'].next_by_code('refill.request.sequence') or _('New')
        refill = super(Refill_request, self).create(vals)
        return refill

    @api.depends('name_seq')
    def survey_link_ids(self):
        survey_id_search = self.env['survey.survey'].sudo().search([('title', '=', 'Prescription Refill for {}'.format(self.name_seq))])
        for rec in self:
            rec.survey_id = survey_id_search.id

    @api.depends('survey_id')
    def get_survey_url(self):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        for rec in self:
            rec.survey_url = str(werkzeug.urls.url_join(base_url, rec.survey_id.get_start_url()))

    def create_customer_survey(self):
        drug_products = self.env['product.product'].search([('categ_id', '=', 12)])
        otc_meds = self.env['product.category'].search([('parent_id', '=', 13)])
        analgesics_drug_products = self.env['product.category'].search([('name', '=', 'Analgesics')])
        # read_group_res = self.env['product.template'].read_group([('categ_id', 'child_of', analgesics_drug_products.ids)], ['categ_id'],
        #                                                         ['categ_id'])
        analgesics_group = self.env['product.product'].search(
            [('categ_id', 'child_of', analgesics_drug_products.ids)])
        survey_count = self.env['survey.survey'].sudo().search_count([('title', '=', self.survey_count2)])
        surveys_created = self.env['survey.survey'].sudo().search([('title', '=', 'Prescription Refill for {}'.format(self.name_seq))])
        if surveys_created:
            raise ValidationError("Survey for this refill has already been created")
        refill_drugs = []
        if self.items:
            for rec in self.items:
                refill_drugs.append(rec.produce.name)
            # print(refill_drugs)
        survey2 = self.env['survey.survey'].create({
            'title': 'Prescription Refill for {}'.format(self.name_seq),
            'customer': self.patient_no.name,
            'access_mode': 'public',
            'questions_layout': 'page_per_question',
            # 'scoring_type': 'scoring_with_answers',
            # 'scoring_success_min': 85.0,
            'state': 'open',
            'users_can_go_back': True,
            # 'background_image':
        })

        simple_choice_answer_1 = self.env['survey.question.answer'].create({
            'value': 'Yes'
        })
        simple_choice_answer_2 = self.env['survey.question.answer'].create({
            'value': 'No'
        })
        # simple_choice_answer_3 = self.env['survey.question.answer'].create({
        #     'value': 'Third'
        # })

        question1 = self.env['survey.question'].create({
            'title': 'Do you want to refill your last prescription?',
            'survey_id': survey2.id,
            'sequence': 1,
            'is_page': False,
            'question_type': 'simple_choice',
            'suggested_answer_ids': [
                (4, simple_choice_answer_1.id),
                (4, simple_choice_answer_2.id),
            ],
        })

        question2 = self.env['survey.question'].create({
            'title': 'Which of these drugs do you want to refill from your last prescriptions?',
            'survey_id': survey2.id,
            'sequence': 2,
            'is_page': False,
            'question_type': 'multiple_choice',
            'suggested_answer_ids': [
                [0, 0, {'sequence': 10, 'value': drug, 'value_image': False, 'is_correct': False, 'answer_score': 0}]
                for drug in refill_drugs],
            'is_conditional': True,
            'triggering_question_id': question1.id,
            'triggering_answer_id': question1.suggested_answer_ids.filtered(lambda answer: answer.value == 'Yes').id
        })

        question3_alt = self.env['survey.question'].create({
            'title': 'Choose any of these drugs you want to refill',
            'survey_id': survey2.id,
            'sequence': 2,
            'is_page': False,
            'question_type': 'multiple_choice',
            'suggested_answer_ids': [[0, 0, {'sequence': 10,
                                             'value': drug.name + " " + drug.product_template_attribute_value_ids._get_combination_name() if drug.product_template_attribute_value_ids.name else drug.name,
                                             'value_image': False, 'is_correct': False, 'answer_score': 0}] for drug in
                                     drug_products],
            'is_conditional': True,
            'triggering_question_id': question1.id,
            'triggering_answer_id': question1.suggested_answer_ids.filtered(lambda answer: answer.value == 'No').id
        })

        question5simple_choice_answer_1 = self.env['survey.question.answer'].create({
            'value': 'Yes'
        })
        question5simple_choice_answer_2 = self.env['survey.question.answer'].create({
            'value': 'No'
        })

        question4_alt = self.env['survey.question'].create({
            'title': 'Did you find the drugs you want to refill',
            'survey_id': survey2.id,
            'sequence': 3,
            'is_page': False,
            'question_type': 'simple_choice',
            'suggested_answer_ids': [
                (4, question5simple_choice_answer_1.id),
                (4, question5simple_choice_answer_2.id),
            ],
            'is_conditional': False,
            'triggering_question_id': False,
            'triggering_answer_id': False
        })

        question5_alt = self.env['survey.question'].create({
            'title': 'Type in the drugs you want to refill', 'survey_id': survey2.id,
            'sequence': 4, 'is_page': False, 'question_type': 'text_box', 'is_conditional': True,
            'triggering_question_id': question4_alt.id, 'triggering_answer_id': question4_alt.suggested_answer_ids.filtered(lambda answer: answer.value == 'No').id})

        # question3 = self.env['survey.question'].create({
        #     'title': 'Choose any of these drugs categories you want to refill',
        #     'survey_id': survey2.id,
        #     'sequence': 2,
        #     'is_page': False,
        #     'question_type': 'simple_choice',
        #     'suggested_answer_ids': [[0, 0, {'sequence': 10,
        #                                      'value': drug_categs.name,
        #                                      'value_image': False, 'is_correct': False, 'answer_score': 0}] for drug_categs in otc_meds],
        #     'is_conditional': True,
        #     'triggering_question_id': question1.id,
        #     'triggering_answer_id': question1.suggested_answer_ids.filtered(lambda answer: answer.value == 'No').id
        # })
        #
        # analgesics_question = self.env['survey.question'].create({
        #     'title': 'Choose any products below to refill',
        #     'survey_id': survey2.id,
        #     'sequence': 3,
        #     'is_page': False,
        #     'question_type': 'multiple_choice',
        #     'suggested_answer_ids': [[0, 0, {'sequence': 10,
        #                                      'value': drug.name + " " + drug.product_template_attribute_value_ids.name if drug.product_template_attribute_value_ids.name else drug.name,
        #                                      'value_image': False, 'is_correct': False, 'answer_score': 0}] for drug in
        #                              analgesics_group],
        #     'is_conditional': True,
        #     'triggering_question_id': question3.id,
        #     'triggering_answer_id': question3.suggested_answer_ids.filtered(lambda answer: answer.value == 'Analgesics').id
        # })
        #survey.create({'title': self.patient_no.name})
        # survey.create(survey_data)
        #survey.write({'question_and_page_ids':[[]]})

    @api.depends('patient_no')
    def open_refill_surveys(self):
        for record in self:
            return {
                'name': _('Refills Surveys'),
                'view_mode': 'list',
                'view_type': 'list, form',
                'res_model': 'survey.survey',
                'type': 'ir.actions.act_window',
                'views': [(False, 'list'), (False, 'form')],
                'target': 'current',
                'domain': [('title', '=', 'Prescription Refill for {}'.format(record.name_seq))]
            }

    @api.depends('patient_no')
    def _compute_items(self):
        for rec in self:
            rec.items = rec.patient_no.produce_bought

    def create_activity(self):
        users = self.env.ref('patient_medication_records.admin_group').users
        print(users)
        for user in users:
            # activity = self.env.ref('patient_medication_records.mail_activity_refill')
            for refill in self.items:
                self.activity_schedule('patient_medication_records.mail_activity_refill', user_id=user.id, date_deadline=refill.next_refill_date, note=f"Please be reminded of this refill request {self.patient_no.name}")

    """@api.depends('patient_no')
    def create_auto_refill(self, values):
        for prescribe in self.patient_no:
            if self.patient_no.name not in prescribe.patient_no:
                return super(Refill_request, self).create(values)"""

    """@api.depends('patient_no')
    def _compute_time(self):
        day = fields.Datetime.to_string(datetime.datetime.now().date())
        self.days = day[:1]+' Days'"""
    @api.depends('items')
    def compute_days_to_refill(self):
        for rec in self:
            if rec.items:
                no_days = []
                for line in rec.items:
                    no_days.append(line.days)
                rec.remaining_days = rec.day + datetime.timedelta(days=min(no_days))

    @api.depends("patient_no")
    def count_surveys(self):
        for rec in self:
            surveys = self.env['survey.survey'].sudo().search_count([('title', '=', 'Prescription Refill for {}'.format(rec.name_seq))])
            rec.survey_count = surveys

    @api.onchange('prescription')
    def load_prescription(self):
        prescribe_ids = []
        for prescribe in self.prescription.produce_bought:
            if prescribe.refill_drug:
                prescribe_ids.append(prescribe.id)
        self.patient_no = self.prescription.name
        self.items = [(6, False, prescribe_ids)]

    @api.depends('items.total_price')
    def _compute_totals(self):
        for order in self:
            total_vals = 0.0
            for line in order.items:
                total_vals += line.total_price
            order.update({
                'total': total_vals,
            })

    def action_refill_send(self):
        ''' Opens a wizard to compose an email, with relevant mail template loaded by default '''
        self.ensure_one()
        template_id = self.env.ref('patient_medication_records.email_refill_request').id
        lang = self.env.context.get('lang')
        template = self.env['mail.template'].browse(template_id)
        if template.lang:
            lang = template._render_lang(self.ids)[self.id]
        ctx = {
            'default_model': 'refill.request',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
            'custom_layout': "mail.mail_notification_light",
            'force_email': True,
        }
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx,
        }

    def action_prescription_send_auto(self):
        ''' Opens a wizard to compose an email, with relevant mail template loaded by default '''
        template_id = self.env.ref('patient_medication_records.email_refill_request').id
        for records in self:
            if fields.Date.today() == records.remaining_days:
                self.env['mail.template'].browse(template_id).send_mail(records.id, force_send=True)

    patient_no = fields.Many2one('res.partner', string='Patient No')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company, store=True, readonly=True, index=True)
    currency_id = fields.Many2one('res.currency', string='Currency', related='company_id.currency_id')
    total = fields.Float(compute='_compute_totals', store=True, readonly=True, tracking=4, default=0)
    survey_id = fields.Many2one('survey.survey', compute="survey_link_ids")
    survey_url = fields.Char(string="Survey url", compute="get_survey_url")
    name_seq = fields.Char("Refill ID", readonly=True, required=True, copy=False, default="New")
    survey_count2 = fields.Char("Surveys created", default="Prescription Refill", store=True)
    prescription = fields.Many2one('patient.prescription')
    #days = fields.Char(compute='_compute_time', string='Days remaining')
    items = fields.One2many('product.verify', 'product_line2', string='Items')
    survey_count = fields.Integer(default=0, compute="count_surveys")
    remaining_days = fields.Date("Refill date", compute="compute_days_to_refill", store=True)
    day = fields.Date(string='Order Date', default=fields.Date.today(), store=True)
    user_id = fields.Many2one('res.users', string="Pharmacist", store=True, default=lambda self: self.env.user)
    form_state = fields.Selection([('draft', 'Draft'), ('confirm', 'Refill Confirmed'), ('cancel', 'Refill Cancelled')],
                             default='draft', string='Status')
