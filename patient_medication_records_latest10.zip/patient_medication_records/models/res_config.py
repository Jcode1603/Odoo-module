from odoo import fields, models, api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    template_id = fields.Many2one('mail.template', 'Email Template',
                                  domain="[('model', '=', 'patient.prescription')]",
                                  config_parameter='patient_medication_records.default_email_template',
                                  default=lambda self: self.env.ref('account.email_template_edi_invoice', False))
    confirmation_template_id = fields.Many2one('mail.template', string='Confirmation Email',
                                               domain="[('model', '=', 'patient.prescription')]",
                                               config_parameter='patient_medication_records.default_confirmation_template',
                                               help="Email sent to the customer once the order is paid.")