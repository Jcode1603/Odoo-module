from odoo.tools import float_is_zero, float_compare
from odoo import api, fields, tools, models, SUPERUSER_ID, _  # imports fields module and models module
from odoo.exceptions import ValidationError


class PricelistItem(models.Model):
    _inherit = 'product.pricelist.item'

    # @api.depends("compute_price", "")
    # def compute_nearest_five(self):
    #     if self.compute_price == 'percentage':
    #         price = (price - (price * (self.percent_price / 100))) or 0.0
    #     nearest_five = total_price / 5
    #     if (total_price - nearest_five) > 3:
    #         nearest_five += 5

    def _compute_price(self, price, price_uom, product, quantity=1.0, partner=False):
        """Compute the unit price of a product in the context of a pricelist application.
           The unused parameters are there to make the full context available for overrides.
        """
        self.ensure_one()
        convert_to_price_uom = (lambda price: product.uom_id._compute_price(price, price_uom))
        if self.compute_price == 'fixed':
            price = convert_to_price_uom(self.fixed_price)
        elif self.compute_price == 'percentage':
            actual_price = (price - (price * (self.percent_price / 100))) or 0.0
            nearest_five = actual_price - (actual_price % 5)
            if (actual_price - nearest_five) > 3:
                nearest_five += 5
            price = nearest_five
            print(price)
        else:
            # complete formula
            price_limit = price
            price = (price - (price * (self.price_discount / 100))) or 0.0
            if self.price_round:
                price = tools.float_round(price, precision_rounding=self.price_round)

            if self.price_surcharge:
                price_surcharge = convert_to_price_uom(self.price_surcharge)
                price += price_surcharge

            if self.price_min_margin:
                price_min_margin = convert_to_price_uom(self.price_min_margin)
                price = max(price, price_limit + price_min_margin)

            if self.price_max_margin:
                price_max_margin = convert_to_price_uom(self.price_max_margin)
                price = min(price, price_limit + price_max_margin)
        return price
