import datetime
import math
from dateutil.relativedelta import relativedelta
from odoo.tools import float_is_zero, float_compare
from odoo import api, fields, models, SUPERUSER_ID, _  # imports fields module and models module
from odoo.exceptions import ValidationError
from odoo.tools.misc import formatLang, get_lang


class ResPartner(models.Model):
    _inherit = 'res.partner'

    sharon_discount_id = fields.Many2one('discount.category', string="Discount Category")


class DiscountCategory(models.Model):
    _name = 'discount.category'

    name = fields.Char(string="Name")
    discount_percentage = fields.Integer(string="Discount_percentage")
