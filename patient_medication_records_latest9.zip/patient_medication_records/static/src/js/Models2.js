odoo.define('point_of_sale.ClientListScreen', function(require) {
    'use strict';

    const {debounce} = owl.utils;
    const PosComponent = require('point_of_sale.PosComponent');
    const Registries = require('point_of_sale.Registries');
    const {useListener} = require('web.custom_hooks');

    class PMRListScreen extends PosComponent {
        async onClick() {
                var self = this;
                const order = this.env.pos.get_order();
                if (order.attributes.client) {
                    var domain = [['name', '=', order.attributes.client.id]];
                    this.rpc({
                        model: 'patient.prescription', method: 'search_read',
                        args: [domain, ['name', 'amount_total']],
                        kwargs: { limit: 5 },
                    }).then(function (orders) {
                        if (orders.length > 0) {
                            var order_list = _.map(orders, function
                            (o) {
                            return { 'label': _.str.sprintf("%s - TOTAL: %s", o.name, o.amount_total) };
                        });
                        self.showPopup('SelectionPopup', { title: 'Last 5 orders', list:order_list });
                        } else {
                        self.showPopup('ErrorPopup', { body: 'No previous orders found' });
                        }
                    });
                } else {
                self.showPopup('ErrorPopup', { body: 'Please select the customer' });
                }
        }
    }
    PMRListScreen.template = "PMRListScreen"
    ProductScreen.addControlButton({
        component: PMRListScreen,
        condition: function (){
            return true;
        }
    });
    Registries.Component.add(PMRListScreen);
})