odoo.define("pos.quotation", function(require) {
    var models = require('point_of_sale.models');

    var _super_pos = models.PosModel.prototype;
    _super_pos.models.push({
        model: 'patient.prescription',
        label: 'load_quotations',
        fields: ['name', 'pos_session_id', 'company_id', 'config_id', 'date', 'name_seq', 'user_id',
            'total', 'currency_id', 'produce_bought'
        ],
        domain: function(self) {
            return [
                ['company_id', '=', self.company.id],
                ['form_state', '=', 'draft']
            ];
        },
        loaded: function(self, pmr) {
            self.pmr = pmr;
            self.db.add_quotations(pmr);
        },
    });
    _super_pos.models.push({
        model: 'product.verify',
        label: 'load_quotations_line',
        fields: ['company_id', 'produce', 'cost', 'prescribed_quantity', 'total_price',
            'product_line', 'measurement', 'currency_id', 'sale_quantity'
        ],
        domain: function(self) {
            return [
                ['company_id', '=', self.company.id]
            ];
        },
        loaded: function(self, pmr_line) {
            self.pmr_lines = pmr_line;
            self.db.add_quotations_lines(pmr_line);
        },
    });

    models.PosModel = models.PosModel.extend({
        initialize: function(attributes, options) {
            _super_pos.initialize.apply(this, arguments);
        },
    });


    var _super_pos_order = models.Order.prototype;
    models.Order = models.Order.extend({
        initialize: function(attributes, options) {
            _super_pos_order.initialize.apply(this, arguments);
            return this;
        },
        export_as_JSON: function() {
            let json = _super_pos_order.export_as_JSON.apply(this, arguments);
            json.pmr_id = this.pmr_id;
            json.record_name = this.record_name;
            json.seller_id = this.seller_id;
            json.seller_id = this.seller_id;
            return json;
        },

        export_for_printing: function() {
            var self = this;
            var receipt = _super_pos_order.export_for_printing.apply(this, arguments);
            if (this.seller_id) {
                const user = self.pos.users.find((user) => user.id = self.seller_id);
                if (user) {
                    receipt['seller'] = user.name
                }
            }
            if (this.pmr_id) {
                var pmr = this.pos.db.get_quotation_by_id(this.pmr_id)
                if (pmr) {
                    receipt['quotation'] = {
                        name: pmr.name_seq,
                        id: pmr.id,
                        customer: pmr.name ? pmr.name[2] : ''
                    }
                }
            }
            return receipt
        }
    });

});