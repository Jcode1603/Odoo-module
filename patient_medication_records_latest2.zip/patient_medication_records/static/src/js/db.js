odoo.define('pos_order_quotation.DB', function(require) {
    "use strict";
    var db = require('point_of_sale.DB');

    db.include({
        init: function(options) {
            this._super.apply(this, arguments);
            this.pmr_records = {}
            this.pmr_by_id = {}
            this.pmr_lines = {}
            this.pmr_lines_by_id = {}
        },

        add_quotations: function(quotations) {
            var self = this;
            quotations.forEach(function(quotation) {
                self.pmr_by_id[quotation.id] = quotation;
                self.pmr_records[quotation.name_seq] = quotation;
            })
        },

        add_quotations_lines: function(quotation_lines) {
            var self = this;
            quotation_lines.forEach(function(quotation) {
                self.pmr_lines[quotation.id] = quotation;
            })
        },

        get_quotation_line_by_id: function(id) {
            return this.pmr_lines[id];
        },

        get_quotation_by_id: function(id) {
            return this.pmr_by_id[id]
        },

        get_quotation_by_ref: function(ref) {
            return this.pmr_records[ref]
        },

    });

    return db
});