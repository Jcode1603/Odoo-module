# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import Patient_medicaion_record
from . import res_config
from . import payment
from . import pos_order
from . import product_category
from . import res_partner
from . import product
from . import refill_process
from . import discount_category
