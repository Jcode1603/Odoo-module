odoo.define('patient_medication_records.DB', function (require) {
    "use strict";

    var core = require('web.core');
    var utils = require('web.utils');
    /* The PosDB holds reference to data that is either
     * - static: does not change between pos reloads
     * - persistent : must stay between reloads ( orders )
     */

    var PosDB2 = core.Class.extend({
        name: 'openerp_pos_db', //the prefix of the localstorage data
        limit: 100,  // the maximum number of results returned by a search
        init: function (options) {
            options = options || {};
            this.name = options.name || this.name;
            this.limit = options.limit || this.limit;

            if (options.uuid) {
                this.name = this.name + '_' + options.uuid;
            }
            this.cache = {};

            this.record_by_id = {};
            this.partner_search_string = "";
            this.partner_sorted = [];
        },
        set_uuid: function(uuid){
            this.name = this.name + '_' + uuid;
        },

        get_pmr_by_id: function(id) {
            return this.record_by_id[id];
        },

        get_pmr_sorted: function(max_count){
            max_count = max_count ? Math.min(this.partner_sorted.length, max_count) : this.partner_sorted.length;
            var partners = [];
            for (var i = 0; i < max_count; i++) {
                partners.push(this.record_by_id[this.partner_sorted[i]]);
            }
            return partners;
        },

        search_pmr: function(query){
            try {
                query = query.replace(/[\[\]\(\)\+\*\?\.\-\!\&\^\$\|\~\_\{\}\:\,\\\/]/g,'.');
                query = query.replace(/ /g,'.+');
                var re = RegExp("([0-9]+):.*?"+utils.unaccent(query),"gi");
            }catch(e){
                return [];
            }
            var results = [];
            for(var i = 0; i < this.limit; i++){
                var r = re.exec(this.partner_search_string);
                if(r){
                    var id = Number(r[1]);
                    results.push(this.get_pmr_by_id(id));
                }else{
                    break;
                }
            }
            return results;
        },

        clear: function(){
            for(var i = 0, len = arguments.length; i < len; i++){
            localStorage.removeItem(this.name + '_' + arguments[i]);
            }
        },
        get_orders: function(){
            return this.load('orders',[]);
        },
        get_order: function(order_id){
            var orders = this.get_orders();
            for(var i = 0, len = orders.length; i < len; i++){
                if(orders[i].id === order_id){
                    return orders[i];
                }
            }
            return undefined;
        },
});

return PosDB2;

});