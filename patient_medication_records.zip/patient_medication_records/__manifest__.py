# -*- coding: utf-8 -*-
###################################################################################
#    Odoo Mates
#    Copyright (C) 2021-TODAY Odoo Mates.
#
#    This program is free software: you can modify

#
###################################################################################
{
    'name': 'Patient medication record',
    'version': '1.3',
    'summary': """Management system for patient records""",
    'description': """Management system for patient records""",
    'category': 'Project',
    'author': 'Joshua Opeyemi',
    'company': 'PSE',
    'maintainer': 'PSE',
    'website': 'http://infinera.com',
    'depends': ['base', 'project', 'mail', 'contacts', 'payment'],
    'data': [
        'security/ir.model.access.csv',
        'views/Patient_medicaion_record.xml',
        'views/pmr_pdf_report.xml',
        'views/report_pmr_document.xml',
        'data/mail_data.xml',
        'data/sale_data.xml',
    ],
    'demo': [
        'security/ir.model.access.csv',
        'views/Patient_medicaion_record.xml',
        'views/pmr_pdf_report.xml',
        'views/report_pmr_document.xml',
    ],
    'images': ['static/description/icon.png'],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
