# -*- coding: utf-8 -*-
###################################################################################
#    Odoo Mates
#    Copyright (C) 2021-TODAY Odoo Mates.
#
#    This program is free software: you can modify

#
###################################################################################
{
    'name': 'Patient medication record',
    'version': '1.3',
    'summary': """Management system for patient records""",
    'description': """Management system for patient records""",
    'category': 'Project',
    'author': 'Joshua Opeyemi',
    'company': 'PSE',
    'maintainer': 'PSE',
    'website': 'http://sharonpharmaceuticals.com',
    'depends': ['base', 'project', 'mail', 'contacts', 'payment', 'crm', 'hr_contract', 'hr_expense', 'sale', 'account', 'point_of_sale'],
    'data': [
        'security/ir.model.access.csv',
        'security/groups.xml',
        'views/Patient_medicaion_record.xml',
        'views/pmr_pdf_report.xml',
        'views/report_pmr_document.xml',
        'data/mail_data.xml',
        'data/sale_data.xml',
        'views/res_partner_views.xml',
        'views/product_template_views.xml',
        'views/pos_views.xml',
        'data/sequence.xml',
        'data/activity.xml',
        'data/activity_pmr.xml',
        'report/report_journal_entries.xml',
        'report/report_journal_entries_view.xml',
    ],
    'qweb': ['static/src/xml/pos_button.xml',
             ],
    'demo': [
        'security/ir.model.access.csv',
        'views/Patient_medicaion_record.xml',
        'views/pmr_pdf_report.xml',
        'views/report_pmr_document.xml',
    ],
    'images': ['static/description/icon.png'],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
