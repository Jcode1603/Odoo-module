odoo.define('patient_medication_records.PMRScreenButton', function (require){
  'use_strict';
  /*
  In order to use ActionButtonWidget, which specified in Screens
  please start with downloading the screens widget
  */
  const { useState } = owl;
  const PosComponent = require('point_of_sale.PosComponent');
  const Registries = require('point_of_sale.Registries');
  const { useListener } = require('web.custom_hooks');
  const ProductScreen = require('point_of_sale.ProductScreen');

//create a button
  class PMRScreenButton extends PosComponent {
        constructor() {
            super(...arguments);
            useListener('click', this.onClick);
        }
        async onClick() {
            try {
                alert("Put an action here")
            } catch (error) {
                alert("no action given")
            }
        }
        /*_start() {
            const self = this;
            async function loop() {
                if (self.env.pos.proxy.posbox_supports_display) {
                    try {
                        const ownership = await self.env.pos.proxy.test_ownership_of_client_screen();
                        if (typeof ownership === 'string') {
                            ownership = JSON.parse(ownership);
                        }
                        if (ownership.status === 'OWNER') {
                            self.state.status = 'success';
                        } else {
                            self.state.status = 'warning';
                        }
                        setTimeout(loop, 3000);
                    } catch (error) {
                        if (error.abort) {
                            // Stop the loop
                            return;
                        }
                        if (typeof error == 'undefined') {
                            self.state.status = 'failure';
                        } else {
                            self.state.status = 'not_found';
                            self.env.pos.proxy.posbox_supports_display = false;
                        }
                        setTimeout(loop, 3000);
                    }
                }
            }
            loop();
        }*/
    }
    PMRScreenButton.template = 'PMRScreenButton2';

    ProductScreen.addControlButton({
        component: PMRScreenButton,
        condition: function() {
            return this.env.pos.config.module_pos_discount && this.env.pos.config.discount_product_id;
        },
    });

    Registries.Component.add(PMRScreenButton);

    return PMRScreenButton;
});