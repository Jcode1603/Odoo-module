odoo.define('patient_medication_records.PMRScreenButton', function (require){
  'use_strict';
  /*
  In order to use ActionButtonWidget, which specified in Screens
  please start with downloading the screens widget
  */
  const { useState } = owl;
  const PosComponent = require('point_of_sale.PosComponent');
  const Registries = require('point_of_sale.Registries');
  const { useListener } = require('web.custom_hooks');
  const ProductScreen = require('point_of_sale.ProductScreen');

//create a button
  // noinspection JSAnnotator
    class PMRScreenButton extends PosComponent {
        constructor() {
            super(...arguments);
            useListener('click', this.onClick);
        }
        async onClick() {
                var self = this;
                const order = this.env.pos.get_order();
                var lines    = order.get_orderlines();
                if (order.attributes.client) {
                    var domain = [['name', '=', order.attributes.client.id]];
                    this.rpc({
                        model: 'patient.prescription', method: 'search_read',
                        args: [domain, ['name', 'date', 'produce_bought', 'total']],
                        kwargs: { limit: 5 },
                    }).then(function (orders) {
                        if (orders.length > 0) {
                            var order_list = _.map(orders, function
                            (o) {
                            return { 'label': _.str.sprintf("%s - DATE: %s - PRODUCT: %s - TOTAL: %s", o.name, o.date, o.produce_bought, o.total) };
                            });
                            var { chosen, payload } = self.showPopup('SelectionPopup', { title: 'Last 5 orders', list:order_list });
                            if (chosen) {
                            self.update_product(order.produce_bought);
                            }
                        } else {
                        self.showPopup('ErrorPopup', { body: 'No previous orders found' });
                        }

                    });
                } else {
                self.showPopup('ErrorPopup', { body: 'Please select the customer' });
                }
        }

        async update_product(pc) {
            var order = this.env.pos.get_order();
            var lines = order.get_orderlines();
            var product = this.env.pos.db.get_product_by_id(pc);
            var productLine = this.get_order(product)
            const options = await this._getAddProductOptions(product);
            this.env.pos.add_new_order()
            this.env.pos.set('selectedOrder', product[0])
            this.env.pos.set_order(product[0]);
            this.product = this.env.pos.db.get_product_by_id(pc)
            this.set_product_lot(this.product);
            this.price = this.product.lst_price;
            order.product = this.product
            order.price = this.price
            /*if (product === undefined) {
                var i = 0;
                while ( i < lines.length ) {
                    if (lines[i].get_product() === product) {
                        order.remove_orderline(lines[i]);
                    } else {
                        i++;
                    }
                }
                return;
            }*/
            // Remove existing discounts

            // Add discount
            // We add the price as manually set to avoid recomputation when changing customer.

            if( product > 0 ){
                if (product === 1){
                    order.orderlines.add(product);
                    productLine
                }else {
                    var i;
                    for (i=0; i<lines.length; i++){
                        try{
                        order.orderlines.add(lines[i]);
                        } catch (e){
                            this.orderlines.add(lines[i])
                        }
                    }
                }

            }
        }


        function () {
            var orderline = new exports.Orderline({},{
                pos: this.pos,
                order: this.order,
                product: this.product,
                price: this.price,
            });
            orderline.order = null;
            orderline.quantity = this.quantity;
            orderline.quantityStr = this.quantityStr;
            orderline.discount = this.discount;
            orderline.price = this.price;
            orderline.selected = false;
            orderline.price_manually_set = this.price_manually_set;
            return orderline;
        }

        /*_start() {
            const self = this;
            async function loop() {
                if (self.env.pos.proxy.posbox_supports_display) {
                    try {
                        const ownership = await self.env.pos.proxy.test_ownership_of_client_screen();
                        if (typeof ownership === 'string') {
                            ownership = JSON.parse(ownership);
                        }
                        if (ownership.status === 'OWNER') {
                            self.state.status = 'success';
                        } else {
                            self.state.status = 'warning';
                        }
                        setTimeout(loop, 3000);
                    } catch (error) {
                        if (error.abort) {
                            // Stop the loop
                            return;
                        }
                        if (typeof error == 'undefined') {
                            self.state.status = 'failure';
                        } else {
                            self.state.status = 'not_found';
                            self.env.pos.proxy.posbox_supports_display = false;
                        }
                        setTimeout(loop, 3000);
                    }
                }
            }
            loop();
        }*/
    }
    PMRScreenButton.template = 'PMRScreenButton2';

    ProductScreen.addControlButton({
        component: PMRScreenButton,
        condition: function() {
            return true;
        },
    });

    Registries.Component.add(PMRScreenButton);

    return PMRScreenButton;
});