odoo.define('patient_medication_record.ActionButton', function(require) {
    "use strict";

    var models = require('point_of_sale.models');
    var core = require('web.core');
    var screens = require('point_of_sale.Screens');
    var _t = core._t;

    //var _super_order = models.Order.prototype;
    /* models.Order = models.Order.extend({
        initialize: function() {
            _super_order.initialize.apply(this, arguments);

            var partner = this.pos.config.default_partner_id;

            if (partner) {
                this.set_client(this.pos.db.get_partner_by_id(partner[0]));
            }
        },
    });

    models.load_models([
    {model: 'patient.prescription',
        fields: ['name', 'patient_no', 'produce_bought'],
        domain: function(){ return [['date', '=', (new Date()).toUTCString()]]; },
        loaded: function(self, prescriptions) {
            self.prescriptions = prescriptions[0];
        }
    },
    ], {'after': 'product.product'}) */

    //create a button
    var DashboardButton = screens.ActionButtonWidget.extend({
        template: 'DashBoardButton',
        button_click: function (){
            alert("Put an action here")
        }
    })

    //define the dashboard button
    screens.define_action_button({
        'name': 'DashBoardButton',
        'widget': DashboardButton,
        'condition': function (){return this.pos}
    })
});