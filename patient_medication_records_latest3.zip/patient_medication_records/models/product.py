import datetime
import math
from dateutil.relativedelta import relativedelta
from odoo.tools import float_is_zero, float_compare
from odoo import api, fields, models, SUPERUSER_ID, _  # imports fields module and models module
from odoo.exceptions import ValidationError
from odoo.tools.misc import formatLang, get_lang


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    @api.depends('categ_id.x_profit_margin', 'standard_price', 'x_additional_markup', 'x_discount_price')
    def _compute_sale_price(self):
        for record in self:
            total = ((record.categ_id.x_profit_margin/100)*record.standard_price)+record.standard_price+((record.x_additional_markup/100)*record.standard_price)
            product_discount=((record.x_additional_discount/100)*total)
            if (total - record.x_discount_price - product_discount)%10 > 0:
                record.list_price = (total - record.x_discount_price - product_discount) + (10-(total - record.x_discount_price - product_discount)%10)
            else:
                record.list_price = total - record.x_discount_price - product_discount

    """@api.depends('categ_id.x_discount', 'categ_id.x_profit_margin', 'standard_price', 'x_additional_markup')"""
    @api.onchange('x_discount_ok')
    def compute_discount_price(self):
        for record in self:
            if record.x_discount_ok:
                total = ((record.categ_id.x_profit_margin/100)*record.standard_price)+record.standard_price+((record.x_additional_markup/100)*record.standard_price)
                record.x_discount_price = ((record.categ_id.x_discount/100)*total)
            else:
                record.x_discount_price = 0.0

    list_price = fields.Float(
        'Sales Price', default=1.0,
        digits='Product Price',
        help="Price at which the product is sold to customers.", compute="_compute_sale_price")
    x_discount_price = fields.Float(string="Discount price", compute="compute_discount_price", store=True)
    x_additional_discount = fields.Float(string="Product markdown %")
    x_additional_markup = fields.Float(string="Additional markup")
    product_sale_points = fields.Float(string="Product sale points")
    x_discount_ok = fields.Boolean(string="Apply discount")
    pmr_uom = fields.Many2one("uom.uom")
    pmr_unit_value = fields.Float(string="Unit conversion value", default=1.00)


class ProductProduct(models.Model):
    _inherit = "product.product"

    def name_get(self):
        res = []
        for account in self:
            # print(account.product_template_attribute_value_ids)
            res.append((account.id, '%s %s %s' % (account.name, account.qty_available, account.product_template_attribute_value_ids._get_combination_name()) or (account.name, account.qty_available)))
        return res

    @api.depends('categ_id.x_profit_margin', 'standard_price', 'x_additional_var_markup', 'x_discount_price')
    def _compute_sale_price(self):
        for record in self:
            total = ((record.categ_id.x_profit_margin / 100) * record.standard_price) + record.standard_price + (
                        (record.x_additional_var_markup / 100) * record.standard_price)
            product_discount = ((record.x_additional_discount / 100) * total)
            if (total - record.x_discount_price - product_discount) % 10 > 0:
                record.list_price = (total - record.x_discount_price - product_discount) + (
                            10 - (total - record.x_discount_price - product_discount) % 10)
            else:
                record.list_price = total - record.x_discount_price - product_discount

    @api.depends('list_price', 'price_extra', 'categ_id.x_profit_margin', 'standard_price', 'x_additional_var_markup', 'x_discount_price')
    @api.depends_context('uom')
    def _compute_product_lst_price_edit(self):
        to_uom = None
        if 'uom' in self._context:
            to_uom = self.env['uom.uom'].browse(self._context['uom'])

        for product in self:
            # print("working")
            if to_uom:
                list_price = product.uom_id._compute_price(product.list_price, to_uom)
            else:
                list_price = product.list_price
            total = ((product.categ_id.x_profit_margin / 100) * product.standard_price) + product.standard_price + (
                        (product.x_additional_var_markup / 100) * product.standard_price)
            product_discount=((product.x_additional_discount/100)*total)
            if (total - product.x_discount_price - product_discount) % 10 > 0:
                product.lst_price = (total - product.x_discount_price) + (10 - (total - product.x_discount_price - product_discount) % 10) + product.price_extra
            else:
                product.lst_price = total - product.x_discount_price + product.price_extra

    @api.onchange('x_discount_ok')
    def compute_discount_price(self):
        for record in self:
            if record.x_discount_ok:
                total = ((record.categ_id.x_profit_margin / 100) * record.standard_price) + record.standard_price + (
                            (record.x_additional_var_markup / 100) * record.standard_price)
                record.x_discount_price = ((record.categ_id.x_discount / 100) * total)
            else:
                record.x_discount_price = 0.0

    x_discount_ok = fields.Boolean(string="Apply discount")
    x_additional_var_markup = fields.Float(string="Additional markup %")

    x_discount_price = fields.Float(string="Discount price", compute="compute_discount_price", store=True)
    x_additional_discount = fields.Float(string="Product markdown %")
    product_sale_points = fields.Float(string="Product sale points")
    pmr_unit_value = fields.Float(string="Unit conversion value", default=1.00)

    lst_price = fields.Float(
        'Public Price', compute='_compute_product_lst_price_edit',
        digits='Product Price', inverse='_set_product_lst_price', store=True,
        help="The sale price is managed from the product template. Click on the 'Configure Variants' button to set the extra attribute prices.")
    product_line = fields.Many2one('patient.prescription', string='product reference', ondelete='cascade', index=True,
                                   copy=False)
    pmr_uom = fields.Many2one("uom.uom")
    pmr_unit_value = fields.Float(string="Unit conversion value", default=1.00)


class Product_temps(models.Model):
    _inherit = 'product.template'

    product_line = fields.Many2one('patient.prescription', string='product reference', ondelete='cascade', index=True, copy=False)