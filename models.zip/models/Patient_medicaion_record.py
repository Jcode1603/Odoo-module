import datetime
from dateutil.relativedelta import relativedelta
from odoo.tools import float_is_zero, float_compare
from odoo import api, fields, models, SUPERUSER_ID, _  # imports fields module and models module
from odoo.exceptions import ValidationError
from odoo.tools.misc import formatLang, get_lang


class SaleOrder(models.Model):
    _inherit = "sale.order"

    def action_quotation_send_proforma(self):
        print("overridden")
        field1 = self.env['crm.lead'].sudo().search([('partner_id', '=', self.partner_id.id)])
        field1.sudo().action_set_won()
        print(self.env.context.get('proforma', True))
        ''' Opens a wizard to compose an email, with relevant mail template loaded by default '''
        self.ensure_one()
        template_id = self._find_mail_template()
        lang = self.env.context.get('lang')
        template = self.env['mail.template'].browse(template_id)
        if template.lang:
            lang = template._render_lang(self.ids)[self.id]
        ctx = {
            'default_model': 'sale.order',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
            'custom_layout': "mail.mail_notification_paynow",
            'proforma': self.env.context.get('proforma', True),
            'force_email': True,
            'model_description': self.with_context(lang=lang).type_name,
        }
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx,
        }

    def create(self, vals):
        print(vals)
        #print(vals['order_line'][0][2]['product_template_id'])
        contact = self.env['res.partner'].sudo().search([('id', '=', vals['partner_id'])])
        products = vals['order_line']
        for i in range(len(products)):
            product = self.env['product.template'].sudo().search([('id', '=', vals['order_line'][i][2]['product_template_id'])])
            print(vals['order_line'][i][2]['name'])
            print(contact.x_partner_discount)
            print(product)
            print(product.product_sale_points)
            contact.sudo().write({"x_partner_discount": (contact.x_partner_discount + product.product_sale_points)})
        print(product.product_sale_points)
        print(contact.x_partner_discount)
        print(self.order_line.product_template_id.product_sale_points)
        res = super(SaleOrder, self).create(vals)
        return res

    @api.depends('order_line.product_template_id')
    def _compute_sale_point(self):
        for record in self:
            sale_point = 0.00
            for line in record.order_line:
                sale_point += line.product_template_id.product_sale_points
            record.update({'sale_points': sale_point})
            #record.sale_points = line.product_template_id.product_sale_points

    sale_points = fields.Float(compute="_compute_sale_point", string="Sale points")

    """def action_quotation_send_proforma(self):
        print("overridden")
        field1 = self.env['crm.lead'].sudo().search([('partner_id', '=', self.partner_id.id)])
        field1.sudo().action_set_won()
        print(self.env.context.get('proforma', True))

        res = super(SaleOrder, self).action_quotation_send_proforma()
        return res"""

    """@api.onchange('order_line.product_template')
    def set_form_values(self):
        for rec in self:
            if rec.order_line.product_template:
                rec.order_line.x_customer_discount = rec.partner_id.x_partner_discount"""
                #rec.order_line.price_unit = rec.order_line.price_unit - rec.order_line.x_customer_discount


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    @api.depends("order_id.partner_id")
    def fill_patient_discount(self):
        if self.order_id.partner_id:
            self.x_customer_discount = self.order_id.partner_id.x_partner_discount

    @api.onchange('product_id')
    def product_id_change(self):
        if not self.product_id:
            return
        valid_values = self.product_id.product_tmpl_id.valid_product_template_attribute_line_ids.product_template_value_ids
        # remove the is_custom values that don't belong to this template
        for pacv in self.product_custom_attribute_value_ids:
            if pacv.custom_product_template_attribute_value_id not in valid_values:
                self.product_custom_attribute_value_ids -= pacv

        # remove the no_variant attributes that don't belong to this template
        for ptav in self.product_no_variant_attribute_value_ids:
            if ptav._origin not in valid_values:
                self.product_no_variant_attribute_value_ids -= ptav

        vals = {}
        if not self.product_uom or (self.product_id.uom_id.id != self.product_uom.id):
            vals['product_uom'] = self.product_id.uom_id
            vals['product_uom_qty'] = self.product_uom_qty or 1.0

        product = self.product_id.with_context(
            lang=get_lang(self.env, self.order_id.partner_id.lang).code,
            partner=self.order_id.partner_id,
            quantity=vals.get('product_uom_qty') or self.product_uom_qty,
            date=self.order_id.date_order,
            pricelist=self.order_id.pricelist_id.id,
            uom=self.product_uom.id
        )

        vals.update(name=self.get_sale_order_line_multiline_description_sale(product))

        self._compute_tax_id()

        if self.order_id.pricelist_id and self.order_id.partner_id:
            vals['price_unit'] = self.env['account.tax']._fix_tax_included_price_company(
                self._get_display_price(product), product.taxes_id, self.tax_id, self.company_id)
        self.update(vals)

        title = False
        message = False
        result = {}
        warning = {}
        if product.sale_line_warn != 'no-message':
            title = _("Warning for %s", product.name)
            message = product.sale_line_warn_msg
            warning['title'] = title
            warning['message'] = message
            result = {'warning': warning}
            if product.sale_line_warn == 'block':
                self.product_id = False

        return result

    @api.onchange("discount_choice")
    def update_discount_on_sale(self):
        if self.discount_choice:
            vals = {}
            product = self.product_id.with_context(
                lang=get_lang(self.env, self.order_id.partner_id.lang).code,
                partner=self.order_id.partner_id,
                quantity=vals.get('product_uom_qty') or self.product_uom_qty,
                date=self.order_id.date_order,
                pricelist=self.order_id.pricelist_id.id,
                uom=self.product_uom.id
            )
            if self.order_id.pricelist_id and self.order_id.partner_id:
                vals['price_unit'] = (self.env['account.tax']._fix_tax_included_price_company(
                    self._get_display_price(product), product.taxes_id, self.tax_id,
                    self.company_id)) - self.x_customer_discount
            self.update(vals)

    x_customer_discount = fields.Float(compute="fill_patient_discount", store=True)
    discount_choice = fields.Boolean("Apply discount", store=True)


class Lead(models.Model):
    _inherit = 'crm.lead'

    def action_set_won_rainbowman(self):
        print("overridden")
        # print(self.name2.id)
        field1 = self.env['crm.lead'].sudo().search([('partner_id', '=', self.partner_id.id)])  # limit=1
        print(field1)
        print(field1.stage_id.sequence)
        # print(field1.stage_id.name)
        proposition_stage_id = self.env['crm.stage'].search([('name', '=', 'Won')], order='sequence').id
        print(proposition_stage_id)
        #field1.sudo().write({'stage_id': proposition_stage_id, 'probability': 100})
        field1.sudo().action_set_propose()
        print(field1.stage_id.sequence)

        rsst = super(Lead, self).action_set_won_rainbowman()
        return rsst

    """stage_id = fields.Many2one(
        'crm.stage', string='Stage', index=True, tracking=True,
        compute='_compute_stage_id', readonly=False,
        copy=False, group_expand='_read_group_stage_ids', ondelete='restrict',
        domain="['|', ('team_id', '=', False), ('team_id', '=', team_id)]")
"""

class ResPartner(models.Model):
    _inherit = 'res.partner'

    def name_get(self):
        res = []
        for account in self:
            res.append((account.id, '%s' % (account.name)))
        return res

    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        if args is None:
            args = []
        domain = args + ['|', ('phone', operator, name), ('name', operator, name)]
        return self._search(domain, limit=limit, access_rights_uid=name_get_uid)

    @api.depends('partner_id')
    def action_open_pos(self):
        for record in self:
            return {
                'name': 'POS records for ' + record.name,
                'view_mode': 'list',
                'view_type': 'list',
                'res_model': 'pos.order',
                'type': 'ir.actions.act_window',
                'target': 'current',
                'domain': [('partner_id', '=', record.name)],
            }

    def _compute_pos_order_count(self):
        # retrieve all children partners and prefetch 'parent_id' on them
        all_partners = self.with_context(active_test=False).search([('id', 'child_of', self.ids)])
        all_partners.read(['parent_id'])

        pos_order_groups = self.env['pos.order'].read_group(
            domain=[('partner_id', 'in', all_partners.ids)],
            fields=['partner_id'], groupby=['partner_id']
        )
        partners = self.browse()
        for group in pos_order_groups:
            partner = self.browse(group['partner_id'][0])
            while partner:
                if partner in self:
                    partner.pos_order_count += group['partner_id_count']
                    partners |= partner
                partner = partner.parent_id
        (self - partners).pos_order_count = 0

    """#@api.depends('import_name.program', 'prog_name')
    def _compute_pos_count2(self):
        for record in self:
            record_count = self.env['pos.order'].sudo().search_count([('partner_id', '=', self.id)])
            record.record_count = record_count"""

    pos_order_count = fields.Integer(compute='_compute_pos_order_count', string='Sale Order Count')


class AccountMove(models.Model):
    _inherit = 'account.move'

    def action_invoice_sent(self):
        # OVERRIDE
        print("overridden")
        #print(self.name2.id)
        field1 = self.env['crm.lead'].sudo().search([('partner_id', '=', self.partner_id.id)])  # limit=1
        print(field1)
        print(field1.stage_id.sequence)
        """proposition_stage_id = self.env['crm.stage'].search([('name', '=', 'Won')]).id
        field1.sudo().write({'stage_id': proposition_stage_id, 'probability': 100})"""
        #field1.stage_id = proposition_stage_id
        #field1.sudo().stage_id.name = "Proposition"
        field1.sudo().action_set_propose()
        print(field1.stage_id.sequence)
        print(field1.stage_id.name)
        print(field1.probability)
        rslt = super(AccountMove, self).action_invoice_sent()

        return rslt

    """def action_register_payment(self):
        field1 = self.env['crm.lead'].sudo().search([('partner_id', '=', self.partner_id.id)])
        field1.sudo().action_set_won()

        res = super(AccountMove, self).action_register_payment()
        return res"""


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    @api.depends('categ_id.x_profit_margin', 'standard_price', 'x_additional_markup', 'x_discount_price')
    def _compute_sale_price(self):
        for record in self:
            total = ((record.categ_id.x_profit_margin/100)*record.standard_price)+record.standard_price+((record.x_additional_markup/100)*record.standard_price)
            product_discount=((record.x_additional_discount/100)*total)
            if (total - record.x_discount_price - product_discount)%10 > 0:
                record.list_price = (total - record.x_discount_price - product_discount) + (10-(total - record.x_discount_price - product_discount)%10)
            else:
                record.list_price = total - record.x_discount_price - product_discount

    """@api.depends('categ_id.x_discount', 'categ_id.x_profit_margin', 'standard_price', 'x_additional_markup')"""
    @api.onchange('x_discount_ok')
    def compute_discount_price(self):
        for record in self:
            if record.x_discount_ok:
                total = ((record.categ_id.x_profit_margin/100)*record.standard_price)+record.standard_price+((record.x_additional_markup/100)*record.standard_price)
                record.x_discount_price = ((record.categ_id.x_discount/100)*total)
            else:
                record.x_discount_price = 0.0

    list_price = fields.Float(
        'Sales Price', default=1.0,
        digits='Product Price',
        help="Price at which the product is sold to customers.", compute="_compute_sale_price")
    x_discount_price = fields.Float(string="Discount price", compute="compute_discount_price", store=True)
    x_additional_discount = fields.Float(string="Product markdown %")
    product_sale_points = fields.Float(string="Product sale points")


class ProductProduct(models.Model):
    _inherit = "product.product"

    @api.depends('list_price', 'price_extra', 'categ_id.x_profit_margin', 'standard_price', 'x_additional_var_markup', 'x_discount_price')
    @api.depends_context('uom')
    def _compute_product_lst_price_edit(self):
        to_uom = None
        if 'uom' in self._context:
            to_uom = self.env['uom.uom'].browse(self._context['uom'])

        for product in self:
            print("working")
            if to_uom:
                list_price = product.uom_id._compute_price(product.list_price, to_uom)
            else:
                list_price = product.list_price
            total = ((product.categ_id.x_profit_margin / 100) * product.standard_price) + product.standard_price + (
                        (product.x_additional_var_markup / 100) * product.standard_price)
            product_discount=((product.x_additional_discount/100)*total)
            if (total - product.x_discount_price - product_discount) % 10 > 0:
                product.lst_price = (total - product.x_discount_price) + (10 - (total - product.x_discount_price - product_discount) % 10) + product.price_extra
            else:
                product.lst_price = total - product.x_discount_price + product.price_extra

    @api.onchange('x_discount_ok')
    def compute_discount_price(self):
        for record in self:
            if record.x_discount_ok:
                total = ((record.categ_id.x_profit_margin / 100) * record.standard_price) + record.standard_price + (
                            (record.x_additional_var_markup / 100) * record.standard_price)
                record.x_discount_price = ((record.categ_id.x_discount / 100) * total)
            else:
                record.x_discount_price = 0.0

    x_discount_ok = fields.Boolean(string="Apply discount")
    x_additional_var_markup = fields.Float(string="Additional markup %")

    x_discount_price = fields.Float(string="Discount price", compute="compute_discount_price", store=True)
    x_additional_discount = fields.Float(string="Product markdown %")
    product_sale_points = fields.Float(string="Product sale points")

    lst_price = fields.Float(
        'Public Price', compute='_compute_product_lst_price_edit',
        digits='Product Price', inverse='_set_product_lst_price', store=True,
        help="The sale price is managed from the product template. Click on the 'Configure Variants' button to set the extra attribute prices.")



class Product_temps(models.Model):
    _inherit = 'product.template'

    product_line = fields.Many2one('patient.prescription', string='product reference', ondelete='cascade', index=True, copy=False)


class Prescription(models.Model):
    _name = 'patient.prescription'  # this will appear in the data base as model_name
    _description = 'create a drug prescription'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    @api.onchange('name')
    def set_customer_details(self):
        for rec in self:
            if rec.name:
                rec.patient_no = rec.name.mobile
                rec.email = rec.name.email
                rec.gender = rec.name.x_gender
                rec.age = rec.name.x_dob

    @api.onchange('produce_bought.produce')
    def set_form_values(self):
        for rec in self:
            if rec.produce_bought.produce:
                rec.produce_bought.measurement = rec.produce_bought.produce.uom_id
                rec.produce_bought.cost = rec.produce_bought.produce.list_price

    @api.model
    def create(self, vals):
        refill = self.env["refill.request"].sudo()
        if vals['to_refill']:
            refill.create({"patient_no": vals['name'], "items": vals['produce_bought']})
        print(vals)
        for rec in self:
            print(self.name.id, self.date)
        program = super(Prescription, self).create(vals)
        #if not vals.get("name", False):
        #values = {"patient_no": self.name, "days": self.date}
        #refill.create(values)
        #refill.write({"patient_no": self.name, "day": self.date})
        return program

    def write(self, vals):
        res = super(Prescription, self).write(vals)
        refill_write = self.env["refill.request"].sudo()
        values = {"patient_no": self.name, "day": self.date}
        for record in refill_write:
            record.write(values)
        return res

    def _create_payment_transaction(self, vals):
        '''Similar to self.env['payment.transaction'].create(vals) but the values are filled with the
        current sales orders fields (e.g. the partner or the currency).
        :param vals: The values to create a new payment.transaction.
        :return: The newly created payment.transaction record.
        '''
        # Ensure the currencies are the same.
        currency = self[0].currency_id
        if any(so.pricelist_id.currency_id != currency for so in self):
            raise ValidationError(_('A transaction can\'t be linked to sales orders having different currencies.'))

        # Ensure the partner are the same.
        partner = self[0].name
        if any(so.partner_id != partner for so in self):
            raise ValidationError(_('A transaction can\'t be linked to sales orders having different partners.'))

        # Try to retrieve the acquirer. However, fallback to the token's acquirer.
        acquirer_id = vals.get('acquirer_id')
        acquirer = False
        payment_token_id = vals.get('payment_token_id')

        if payment_token_id:
            payment_token = self.env['payment.token'].sudo().browse(payment_token_id)

            # Check payment_token/acquirer matching or take the acquirer from token
            if acquirer_id:
                acquirer = self.env['payment.acquirer'].browse(acquirer_id)
            else:
                acquirer = payment_token.acquirer_id

        if not acquirer:
            acquirer = self.env['payment.acquirer'].browse(acquirer_id)

        # Check a journal is set on acquirer.

        if not acquirer_id and acquirer:
            vals['acquirer_id'] = acquirer.id

        vals.update({
            'amount': sum(self.mapped('amount_total')),
            'currency_id': currency.id,
            'partner_id': partner.id,
            'sale_order_ids': [(6, 0, self.ids)],
            #'type': self[0]._get_payment_type(vals.get('type')=='form_save'),
        })

        transaction = self.env['payment.transaction'].create(vals)

        # Process directly if payment_token
        if transaction.payment_token_id:
            transaction.s2s_do_transaction()

        return transaction

    @api.depends('gender')
    def compute_count(self):
        self.total = sum([int(line) for line in self.gender])

    @api.depends('produce_bought.cost')
    def _compute_totals(self):
        for order in self:
            total_vals = 0.0
            for line in order.produce_bought:
                total_vals += line.cost
            order.update({
                'total': total_vals,
            })
    '''
    def _amount_all(self):
        """
        Compute the total amounts of the SO.
        """
        for order in self:
            amount_untaxed = amount_tax = 0.0
            for line in order.order_line:
                amount_untaxed += line.price_subtotal
                amount_tax += line.price_tax
            order.update({
                'amount_untaxed': amount_untaxed,
                'amount_tax': amount_tax,
                'amount_total': amount_untaxed + amount_tax,
            })'''
    def _find_mail_template(self):
        template_id = False

        if self.form_state == 'confirm' and not self.env.context.get('proforma', False):
            template_id = int(self.env['ir.config_parameter'].sudo().get_param('patient_medication_records.default_confirmation_template'))
            template_id = self.env['mail.template'].search([('id', '=', template_id)]).id
            if not template_id:
                template_id = self.env['ir.model.data'].xmlid_to_res_id('patient_medication_records.mail_template_sale_confirmation', raise_if_not_found=False)
        #if not template_id:
            #template_id = self.env['ir.model.data'].xmlid_to_res_id('patient_medication_records.email_template_edi_sale', raise_if_not_found=False)

        return template_id

    def action_quotation_send(self):
        ''' Opens a wizard to compose an email, with relevant mail template loaded by default '''
        self.ensure_one()
        template_id = self._find_mail_template()
        lang = self.env.context.get('lang')
        template = self.env['mail.template'].browse(template_id)
        if template.lang:
            lang = template._render_lang(self.ids)[self.id]
        ctx = {
            'default_model': 'patient.prescription',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
            'custom_layout': "mail.mail_notification_paynow",
            'proforma': self.env.context.get('proforma', False),
            'force_email': True,
            'model_description': self.with_context(lang=lang).type_name,
        }
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx,
        }

    def _compute_current_date(self):
        for record in self:
            record.date_order = datetime.datetime.now()

    @api.depends('form_state', 'invoice_status')
    def _get_invoice_status(self):
        """
        Compute the invoice status of a SO. Possible statuses:
        - no: if the SO is not in status 'sale' or 'done', we consider that there is nothing to
          invoice. This is also the default value if the conditions of no other status is met.
        - to invoice: if any SO line is 'to invoice', the whole SO is 'to invoice'
        - invoiced: if all SO lines are invoiced, the SO is invoiced.
        - upselling: if all SO lines are invoiced or upselling, the status is upselling.
        """
        unconfirmed_orders = self.filtered(lambda so: so.form_state not in ['confirm', 'done'])
        unconfirmed_orders.invoice_status = 'no'
        confirmed_orders = self - unconfirmed_orders
        if not confirmed_orders:
            return
        line_invoice_status_all = [
            (d['order_id'][0], d['invoice_status'])
            for d in self.env['product.verify'].read_group([
                ('order_id', 'in', confirmed_orders.ids),
                ('is_downpayment', '=', False),
                ('display_type', '=', False),
            ],
                ['order_id', 'invoice_status'],
                ['order_id', 'invoice_status'], lazy=False)]
        for order in confirmed_orders:
            line_invoice_status = [d[1] for d in line_invoice_status_all if d[0] == order.id]
            if order.form_state not in ('confirm', 'done'):
                order.invoice_status = 'no'
            elif any(invoice_status == 'to invoice' for invoice_status in line_invoice_status):
                order.invoice_status = 'to invoice'
            elif line_invoice_status and all(invoice_status == 'invoiced' for invoice_status in line_invoice_status):
                order.invoice_status = 'invoiced'
            elif line_invoice_status and all(
                    invoice_status in ('invoiced', 'upselling') for invoice_status in line_invoice_status):
                order.invoice_status = 'upselling'
            else:
                order.invoice_status = 'no'

    @api.depends('name')
    def action_open_refills(self):
        for record in self:
            return {
                'name': 'Records for ' + record.name,
                'view_mode': 'list',
                'view_type': 'list',
                'res_model': 'refill.request',
                'type': 'ir.actions.act_window',
                'target': 'current',
                'domain': [('patient_no', '=', record.name)],
            }

    def get_portal_last_transaction(self):
        self.ensure_one()
        return self.transaction_ids.get_last_transaction()

    def _create_invoice(self):
        invoice_list = self.env['account.move'].sudo().create()
        return invoice_list

    def action_pos_link(self):
        sales_product = self.env['pos.order'].sudo().create()
        return sales_product

    @api.depends('form_state')
    def _compute_type_name(self):
        for record in self:
            record.type_name = _('Quotation') if record.form_state in ('draft', 'confirm') else _('Pharma Order')

    def _get_presc_advice(self):
        for record in self:
            record.description = "Take {} tablets {} times daily".format(record.produce_bought.dosage, record.produce_bought.frequency)

    @api.onchange("produce_bought")
    def _update_vals(self):
        ctx_lines = self.env.context.get('produce_bought')
        changed_lines_lst = []
        if ctx_lines:
            for ctx_line in ctx_lines:
                if ctx_line[2]:
                    if ctx_line[2].get("produce"):
                        changed_lines_lst.append(ctx_line[1])

        for order in self:
            order.produce_bought.cost = order.produce_bought.produce.list_price
            order.produce_bought.avail_quantity = order.produce_bought.produce.qty_available

    @api.constrains("produce_bought.prescribed_quantity", "produce_bought.avail_quantity")
    def _constrain_quantity(self):
        for rec in self:
            if rec.produce_bought.prescribed_quantity and rec.produce_bought.avail_quantity:
                if any(rec.produce_bought.avail_quantity < rec.produce_bought.prescribed_quantity):
                    raise ValidationError(_("You cannot prescribe more than the available quantity"))

    @api.depends("produce_bought.total_price")
    def final_total(self):
        for rec in self:
            finalcost=[]
            for record in rec.produce_bought:
                finalcost.append(record.produce_bought.total_price)
            rec.final_total = sum(finalcost)

    # patient details field
    name = fields.Many2one('res.partner', string="Customer's id", required=True, index=True, tracking=1, store=True)  # this creates a variable 'name' with a character type field
    patient_no = fields.Char(string="Customer's name")
    email = fields.Char(string='Email', required=True)
    gender = fields.Selection([('male', 'M'), ('female', 'F')], string='Gender')
    age = fields.Date(string='D.O.B', store=True)
    image = fields.Image("Signature", max_width=1920, max_height=1920)
    #crop_type = fields.Selection([('maize', 'Maize'), ('soybeans', 'Soybeans'), ('sorghum', 'Sorghum'), ('cowpea', 'Cowpea'), ('sesame', 'Sesame'), ('rice', 'Rice'), ('cassava', 'Cassava')], string='Crop type')
    allergies = fields.Char(string='Allergies')
    to_refill = fields.Boolean(string='To be refilled')
    date = fields.Datetime(string='Order Date', required=True, readonly=True, index=True, form_states={'draft': [('readonly', False)], 'confirm': [('readonly', False)]}, copy=False,
                                 default=fields.Datetime.now, help="Creation date of draft/sent orders,\nConfirmation date of confirmed orders.", store=True)
    #date_order = fields.Datetime(compute='_compute_current_date', string='Date Created', store=True)
    type_name = fields.Char('Type Name', compute='_compute_type_name')
    form_state = fields.Selection([('draft', 'Draft'), ('confirm', 'Confirmed'), ('done', 'Done'), ('cancel', 'Cancelled')],
                             default='draft', string='Status')
    produce_bought = fields.One2many('product.verify', 'product_line', string='Drug Orders', copy=True, auto_join=True)
    #services fields
    invoice_status = fields.Selection([
        ('upselling', 'Upselling Opportunity'),
        ('invoiced', 'Fully Invoiced'),
        ('to invoice', 'To Invoice'),
        ('no', 'Nothing to Invoice')], compute="_get_invoice_status", string='Invoice Status', store=True, readonly=True)

    priority = fields.Selection([('0', 'Very Low'), ('1', 'Low'), ('2', 'Normal'), ('3', 'High')], string='Priority')
    user_id = fields.Many2one('res.users', string="Pharmacist", default=lambda self: self.env.user)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company, store=True, readonly=True, index=True)
    currency_id = fields.Many2one('res.currency', string='Currency', related='company_id.currency_id')
    signature = fields.Image(string="Signature")
    transaction_ids = fields.Many2many('payment.transaction', 'drug_order_transaction_rel', 'sale_order_id', 'transaction_id',
                                       string='Transactions', copy=False, readonly=True)
    values = {"patient no": name, "Days": date, "Drugs": produce_bought}
    color = fields.Integer()
    total = fields.Integer(compute='_compute_totals', store=True, readonly=True, tracking=4, default=0)
    description = fields.Text("Prescription advice", compute="_get_presc_advice")
    advice_temp = fields.Many2one('advice.template')
    kanban_state = fields.Selection([('normal', 'In Progress'), ('done', 'Done'), ('blocked', 'Blocked')],
                                    default='normal')
    refill = fields.Many2one("refill.request")
    reference = fields.Char('Order reference', compute="_calc_ref_no")
    #final_total = fields.Monetary(compute="final_total")

    def _calc_ref_no(self):
        number = sum([rec for rec in self])
        return "000"+number

    def action_invoice_print(self):
        if self.total > 0:
            return self.env.ref('account.account_invoices').report_action(self)
        else:
            return self.env.ref('account.account_invoices_without_payment').report_action(self)
    '''
    # activity_ids = fields.One2many('mail.activity', 'calendar_event_id', string='Activities')
    program = fields.Many2one('farm.program', store=True)
    form_state = fields.Selection([('draft', 'Draft'), ('confirm', 'Confirmed'), ('done', 'Done'), ('cancel', 'Cancelled')],
                             default='draft', string='Status')
    input_costs = fields.Many2many('farm.eop.inputcost', 'farm_name')
    mech_costs = fields.Many2many('farm.mech')
    labour_costs = fields.Many2many('labour.farm')
    sub_total = fields.Monetary(compute='_compute_sub_total', store=True, string='Sub total')
    input_total = fields.Float(compute='_compute_input_totals')
    mech_total = fields.Float(compute='_compute_mech_totals')
    labour_total = fields.Float(compute='_compute_labour_totals')
    insurance_amount = fields.Monetary(compute='_compute_insurance_total', store=True, string='Insurance Amount')
    mande_amount = fields.Monetary(compute='_compute_mande', store=True, string='M&E Amount')
    admin_amount = fields.Monetary(compute='_compute_adminfee', store=True, string='Admin Fee')
    total_production = fields.Monetary(compute='_compute_total_prod', store=True, string='Total production costs', currency_field='currency_id', tracking=True)'''


class product_verify(models.Model):
    _name = 'product.verify'
    _description = 'This class creates different farmer programs'
    _rec_name = 'prod_name'

    """@api.onchange('produce')
    def set_form_values(self):
        for rec in self:
            if rec.produce:
                #rec.measurement = rec.produce.uom_id
                #rec.cost = rec.produce.list_price"""

    """@api.onchange("produce")
    def _update_product_form(self):
        self.produce_bought = self.env['patient.prescription'].search(
            [('One2manyFieldName', '=', self.many2one_field)])"""

    @api.constrains("prescribed_quantity", "avail_quantity")
    def _constrain_quantity(self):
        for rec in self:
            if rec.prescribed_quantity and rec.avail_quantity:
                if rec.prescribed_quantity > rec.avail_quantity:
                    raise ValidationError(_("You cannot prescribe more than the available quantity"))

    @api.onchange("produce")
    def _update_vals(self):
        if self.produce:
            self.cost = self.produce.list_price
            self.avail_quantity = self.produce.qty_available

    @api.depends('state', 'cost')
    def _compute_invoice_status(self):
        for line in self:
            if line.state not in ('confirm', 'done'):
                line.invoice_status = 'no'
            elif line.is_downpayment == 0:
                line.invoice_status = 'invoiced'
            elif not float_is_zero(line.qty_to_invoice, precision_digits=precision):
                line.invoice_status = 'to invoice'
            elif line.form_state == 'confirm':
                line.invoice_status = 'upselling'
            else:
                line.invoice_status = 'no'

    def _compute_record_count2(self):
        for record in self:
            record.prescribed_quantity = record.dosage*record.frequency*record.days

    def _compute_total_cost(self):
        for rec in self:
            rec.total_price = rec.prescribed_quantity*rec.cost

    prod_name = fields.Many2one('labour.farm', string='Name')
    prescribed_quantity = fields.Integer(compute='_compute_record_count2', string="Prescribed qty")
    avail_quantity = fields.Integer(string="Available qty")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company, store=True,
                                 readonly=True, index=True)
    currency_id = fields.Many2one('res.currency', string='Currency', related='company_id.currency_id')
    measurement = fields.Selection([('tablets', 'Tablets'), ('capsules', 'Capsules')], string='UOM')
    #user_id = fields.Many2one('res.users', string='Project Manager', tracking=True)
    frequency = fields.Integer(string='Frequency')
    refill_drug = fields.Boolean(string='drug refillable?')
    days = fields.Integer(string="Days")
    dosage = fields.Integer(string="Dosage")
    state = fields.Selection([('draft', 'Draft'), ('confirm', 'Confirmed'), ('done', 'Done'), ('cancel', 'Cancelled')],
                             default='draft', string='Status')
    produce = fields.Many2one('product.template', string='Drug Orders', copy=True, auto_join=True, required=True)
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False, help="Technical field for UX purpose.")
    is_downpayment = fields.Boolean(
        string="Is a down payment", help="Down payments are made when creating invoices from a sales order."
                                         " They are not copied when duplicating a sales order.")
    estimate = fields.Integer(string='Estimated days')
    order_id = fields.Many2one('patient.prescription')
    cost = fields.Float(string="Unit Price")
    total_price = fields.Float(string="Total price", compute="_compute_total_cost", store=True)
    invoice_status = fields.Selection([
        ('upselling', 'Upselling Opportunity'),
        ('invoiced', 'Fully Invoiced'),
        ('to invoice', 'To Invoice'),
        ('no', 'Nothing to Invoice')
    ], string='Invoice Status', compute='_compute_invoice_status', store=True, readonly=True, default='no')
    product_line = fields.Many2one('patient.prescription', string='product reference', ondelete='cascade', index=True, copy=False)
    product_line2 = fields.Many2one('refill.request', string="refill reference", index=True)
    description = fields.Text("Prescription advice")
    advice_temp = fields.Many2one('advice.template')
    #is_favorite = fields.Boolean(string='Favourite Program', compute='_compute_is_favorite', inverse='_inverse_is_favorite', default=True)
    #program_state = fields.Selection([('normal', 'In Progress'), ('done', 'Done'), ('blocked', 'Blocked')], default='normal')

    '''@api.depends('prog_name')
    def action_view_accounts(self):
        action = self.with_context(active_id=self.id, active_ids=self.ids) \
            .env.ref('Farmers_account.action_account_link') \
            .sudo().read()[0]
        action['display_name'] = self.name
        return action'''


class Refill_request(models.Model):
    _name = 'refill.request'
    _description = 'this class computes refill of different medical products'
    _rec_name = 'patient_no'

    @api.model
    def create(self, vals):
        field1 = self.env['patient.prescription'].search([('name', '=', 10)])
        field1.form_state = "draft"
        for records in field1:
            print(records.name)
        #vals.update({'day': field1})
        refill = super(Refill_request, self).create(vals)
        return refill

    @api.depends('patient_no')
    def _compute_items(self):
        for rec in self:
            rec.items = rec.patient_no.produce_bought

    """@api.depends('patient_no')
    def create_auto_refill(self, values):
        for prescribe in self.patient_no:
            if self.patient_no.name not in prescribe.patient_no:
                return super(Refill_request, self).create(values)"""

    """@api.depends('patient_no')
    def _compute_time(self):
        day = fields.Datetime.to_string(datetime.datetime.now().date())
        self.days = day[:1]+' Days'"""

    patient_no = fields.Many2one('res.partner', string='Patient No')
    day = fields.Datetime(string='Order Date', default=fields.Datetime.now)
    #days = fields.Char(compute='_compute_time', string='Days remaining')
    items = fields.One2many('product.verify', 'product_line2', string='Items')
    form_state = fields.Selection([('draft', 'Draft'), ('confirm', 'Refill Confirmed'), ('cancel', 'Refill Cancelled')],
                             default='draft', string='Status')


'''class Labour_cost(models.Model):
    _name = 'labour.farm'
    _description = 'for computing the labour costs on the farm'

    @api.depends('gender')
    def _compute_record_count2(self):
        for record in self:
            record_count = self.env['farmers.infinera'].sudo().search_count([('program', '=', record.prog_name)])
            record.record_count = record_count
    gender = fields.Char(default='M')'''


class Prescribe_advice(models.Model):
    _name = "advice.template"
    _description = "Templates for prescription advice"
    _rec_name = 'description'

    name = fields.Char(string="Template name")
    description = fields.Char(string="Template advice")


